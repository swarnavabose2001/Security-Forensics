#include <iostream>
#include <string>
#include <cstring>
#include <thread>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define PORT 12345
#define MULTICAST_GROUP "239.0.0.1"
#define BUFFER_SIZE 1024

using namespace std;

string self_id;
string peer_id;

void receive_messages(int sock, struct ip_mreq mreq) {
    char buffer[BUFFER_SIZE];

    while (true) {
        sockaddr_in sender_addr;
        socklen_t addrlen = sizeof(sender_addr);
        int nbytes = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0,
                              (struct sockaddr*)&sender_addr, &addrlen);
        if (nbytes < 0) {
            perror("recvfrom");
            exit(1);
        }

        buffer[nbytes] = '\0';

        string msg(buffer);
        size_t sep1 = msg.find('|');
        size_t sep2 = msg.find('|', sep1 + 1);

        if (sep1 == string::npos || sep2 == string::npos) continue;

        string sender = msg.substr(0, sep1);
        string recipient = msg.substr(sep1 + 1, sep2 - sep1 - 1);
        string content = msg.substr(sep2 + 1);

       
        if (recipient == self_id) {
            cout << "[" << sender << "]: " << content << endl;
        }
    }
}

int main() {
    cout << "Enter your ID: ";
    getline(cin, self_id);

    cout << "Enter peer ID to chat with: ";
    getline(cin, peer_id);

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("socket");
        exit(1);
    }

    int reuse = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse)) < 0) {
        perror("setsockopt SO_REUSEADDR");
        exit(1);
    }

    struct sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(PORT);

    if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        exit(1);
    }

    struct ip_mreq mreq{};
    mreq.imr_multiaddr.s_addr = inet_addr(MULTICAST_GROUP);
    mreq.imr_interface.s_addr = htonl(INADDR_ANY);

    if (setsockopt(sock, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&mreq, sizeof(mreq)) < 0) {
        perror("setsockopt mreq");
        exit(1);
    }

    thread receiver(receive_messages, sock, mreq);

    while (true) {
        string message;
        cout << "[You]: ";
        getline(cin, message);

        if (message == "/exit") break;

        string full_message = self_id + "|" + peer_id + "|" + message;

        sockaddr_in group_addr{};
        group_addr.sin_family = AF_INET;
        group_addr.sin_addr.s_addr = inet_addr(MULTICAST_GROUP);
        group_addr.sin_port = htons(PORT);

        int nbytes = sendto(sock, full_message.c_str(), full_message.length(), 0,
                            (struct sockaddr*)&group_addr, sizeof(group_addr));
        if (nbytes < 0) {
            perror("sendto");
            exit(1);
        }
    }

    setsockopt(sock, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char *)&mreq, sizeof(mreq));
    close(sock);
    return 0;
}
