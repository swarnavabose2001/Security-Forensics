#include <bits/stdc++.h>
using namespace std;


long long mod_exp(long long base, long long exp, long long mod) {
    long long result = 1;
    while (exp > 0) {
        if (exp % 2 == 1)
            result = (result * base) % mod;
        base = (base * base) % mod;
        exp /= 2;
    }
    return result;
}


struct ElGamalKey {
    long long p, g, x, y;  
};

ElGamalKey generate_keys() {
    ElGamalKey key;
    key.p = 787; 
    key.g = 2;  
    key.x = rand() % (key.p - 2) + 1;  
    key.y = mod_exp(key.g, key.x, key.p);  
    return key;
}


pair<long long, long long> elgamal_encrypt(long long msg, long long p, long long g, long long y) {
    long long k = rand() % (p - 2) + 1;
    long long a = mod_exp(g, k, p);
    long long b = (mod_exp(y, k, p) * msg) % p;
    return {a, b};
}


long long elgamal_decrypt(pair<long long, long long> cipher, long long p, long long x) {
    long long a = cipher.first, b = cipher.second;
    long long s = mod_exp(a, x, p);
    long long s_inv = mod_exp(s, p - 2, p); 
    return (b * s_inv) % p;
}


void rc4_init(vector<int>& S, const vector<int>& key) {
    int j = 0;
    for (int i = 0; i < 256; i++) S[i] = i;
    for (int i = 0; i < 256; i++) {
        j = (j + S[i] + key[i % key.size()]) % 256;
        swap(S[i], S[j]);
    }
}

vector<int> rc4_encrypt_decrypt(const vector<int>& plaintext, const vector<int>& key) {
    vector<int> S(256);
    rc4_init(S, key);
    vector<int> ciphertext(plaintext.size());
    int i = 0, j = 0;
    for (size_t k = 0; k < plaintext.size(); k++) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        swap(S[i], S[j]);
        int rnd = S[(S[i] + S[j]) % 256];
        ciphertext[k] = plaintext[k] ^ rnd;
    }
    return ciphertext;
}

int main() {
    srand(time(0));
    
    ElGamalKey key = generate_keys();
    cout << "ElGamal Public Key (p, g, y): " << key.p << ", " << key.g << ", " << key.y << endl;
 
    int rc4_key_value;
    cout << "Enter an integer RC4 Key (0-255): ";
    cin >> rc4_key_value;
    

    auto encrypted_rc4_key = elgamal_encrypt(rc4_key_value, key.p, key.g, key.y);
    cout << "Encrypted RC4 Key: (" << encrypted_rc4_key.first << ", " << encrypted_rc4_key.second << ")\n";
    
    int decrypted_rc4_key = elgamal_decrypt(encrypted_rc4_key, key.p, key.x);
    cout << "Decrypted RC4 Key: " << decrypted_rc4_key << endl;

    vector<int> rc4_key = {decrypted_rc4_key};

    string message;
    cout << "Enter the message to encrypt: ";
    cin.ignore();
    getline(cin, message);
    vector<int> plaintext(message.begin(), message.end());
    

    vector<int> ciphertext = rc4_encrypt_decrypt(plaintext, rc4_key);
    cout << "Ciphertext: ";
    for (int c : ciphertext) cout << c << " ";
    cout << endl;
    
    vector<int> decrypted_text = rc4_encrypt_decrypt(ciphertext, rc4_key);
    string decrypted_message(decrypted_text.begin(), decrypted_text.end());
    cout << "Decrypted Message: " << decrypted_message << endl;
    
    return 0;
}

