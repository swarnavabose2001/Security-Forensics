#include <iostream>
#include <fstream>
#include <bitset>
#include <string>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

// Function to encode binary text into an image
void encodeTextInImage(Mat& image, const string& text) {
    string binaryText = "";

    // Append a special delimiter to indicate end of the message
    string textWithDelimiter = text + "###";  

    for (char c : textWithDelimiter) {
        bitset<8> bits(c);
        binaryText += bits.to_string();
    }

    int pixelIndex = 0;
    int binaryTextSize = binaryText.size();
    int rows = image.rows;
    int cols = image.cols;

    for (int r = 0; r < rows && pixelIndex < binaryTextSize; r++) {
        for (int c = 0; c < cols && pixelIndex < binaryTextSize; c++) {
            Vec3b& pixel = image.at<Vec3b>(r, c);
            for (int channel = 0; channel < 3 && pixelIndex < binaryTextSize; channel++) {
                char bit = binaryText[pixelIndex++];
                int pixelValue = pixel[channel];

                if (bit == '0') {
                    pixel[channel] = (pixelValue % 2 == 0) ? pixelValue : pixelValue - 1;
                } else {  
                    pixel[channel] = (pixelValue % 2 == 1) ? pixelValue : pixelValue + 1;
                }
            }
        }
    }

    imwrite("encoded_image.png", image);
}

// Function to decode hidden text from an image
string decodeTextFromImage(const Mat& image) {
    string binaryText = "";
    int rows = image.rows;
    int cols = image.cols;

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            Vec3b pixel = image.at<Vec3b>(r, c);
            for (int channel = 0; channel < 3; channel++) {
                binaryText += (pixel[channel] % 2) ? '1' : '0';
            }
        }
    }

    // Convert binary to characters
    string extractedText = "";
    for (size_t i = 0; i < binaryText.size(); i += 8) {
        string byteStr = binaryText.substr(i, 8);
        char character = static_cast<char>(bitset<8>(byteStr).to_ulong());

        if (extractedText.size() >= 3 && extractedText.substr(extractedText.size() - 3) == "###") {
            extractedText.erase(extractedText.size() - 3); // Remove delimiter
            break;
        }

        extractedText += character;
    }

    return extractedText;
}

int main() {
    int choice;
    cout << "Choose an option: \n1. Encode text\n2. Decode text\n";
    cin >> choice;
    cin.ignore();

    if (choice == 1) {
        string text;
        cout << "Enter the text to encode in the image: ";
        getline(cin, text);

        Mat image = imread("input_image.png"); 

        if (image.empty()) {
            cerr << "Could not open or find the image!" << endl;
            return -1;
        }

        encodeTextInImage(image, text);
        cout << "Text encoding completed. Image saved as 'encoded_image.png'" << endl;
    } 
    else if (choice == 2) {
        Mat encodedImage = imread("encoded_image.png");

        if (encodedImage.empty()) {
            cerr << "Could not open or find the encoded image!" << endl;
            return -1;
        }

        string decodedText = decodeTextFromImage(encodedImage);
        cout << "Decoded text: " << decodedText << endl;
    } 
    else {
        cout << "Invalid choice!" << endl;
    }

    return 0;
}
